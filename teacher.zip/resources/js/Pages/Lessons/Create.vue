<script setup>
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import {Head} from "@inertiajs/vue3";

defineOptions({
    layout: AuthenticatedLayout
})
</script>

<template>
    <Head title="Create Lesson"/>
</template>
