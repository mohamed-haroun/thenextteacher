<template>
    <img src="/teacher.png" alt="Teacher icon">
</template>
