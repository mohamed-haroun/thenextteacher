<script setup>

</script>

<template>
    <header class="mt-5 mb-2 w-11/12 mx-auto ">
        <div class="max-w-7xl mx-auto py-2 md:py-3 text-gray-80 dark:text-gray-200 px-4 sm:px-6 lg:px-8 font-bold text-lg sm:text-2xl">
            <slot/>
        </div>
    </header>
</template>
